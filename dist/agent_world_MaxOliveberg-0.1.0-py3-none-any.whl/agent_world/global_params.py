# These parameters should not be changed

second = 1000
minute = 60 * second
hour = 60 * minute
day = 24 * hour
