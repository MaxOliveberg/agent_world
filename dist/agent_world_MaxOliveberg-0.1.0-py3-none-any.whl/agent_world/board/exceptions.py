class InvalidCoordinateException(Exception):
    pass
