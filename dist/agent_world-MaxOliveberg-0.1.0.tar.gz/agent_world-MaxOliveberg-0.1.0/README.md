This is a collection of tools used to run agent based simulations for idle/"farmville style" games. It is 
developed by Max Oliveberg and is currently very rudimentary.